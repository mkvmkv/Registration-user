<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mukec extends CI_Controller 
{
	function __Construct()
	{
		parent::__Construct ();
		$this->load->database(); // load database
		$this->load->model('Mukem'); // load model 
 	}
	public function index()
	{
		$this->load->view('registration');
		//echo $this->db->platform();
		//echo $this->db->version();
	}
	public function login()
	{
		
			$data = array('upload_data' => $this->upload->data());
			$data = array(
				'username' => $this->input->post('username'),
				'father' => $this->input->post('father'),
				'gender' => $this->input->post('gender'),
				'userfile' => $this->input->post('userfile'),
				'first' => $this->input->post('first'),
				'second' => $this->input->post('second'),
				'third' => $this->input->post('third'),
				'salary' => $this->input->post('salary'),
			);
			$this->Mukem->insert_data($data);
			$data['message'] = 'Data Inserted Successfully';
			$this->load->view('registration', $data);
	}

		
}
?>