<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mukem Extends CI_Model
{
    public function insert_data($data)
    {
        $this->db->insert('login',$data);
    }


}
?>