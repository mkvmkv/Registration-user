<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>
<h3>Login Form</h3>
<form name="h2" action="<?php echo base_url();?>index.php/Mukec/login" method="post">
Username :<input type="text" name="username"><br/><br/>
Father Name :<input type="text" name="father"><br/><br/>
Gender   :<input type="radio" name="gender" value="Male">Male &nbsp;&nbsp;&nbsp;<input type="radio" name="gender" value="Female">Female<br/><br/>
Img Upload <input type="file" name="userfile"><br/><br/>
Education <input type="checkbox" name="first" value="10th">10th
<input type="checkbox" name="second" value="12th">12th
<input type="checkbox" name="third" value="grduate">Graduation<br/><br/>
Salay <input type="salary" name="salary"><br/><br/>
<input type="submit" name="submit" value="Add">
</body>
</html>